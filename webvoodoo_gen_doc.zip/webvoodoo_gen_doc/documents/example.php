<div class="contents faded_panel thumbs settings" id="contents">
    <div class="paragraph" id="eYZSR214" data-parentid="eWXMI975" level="1" data-id="e0">
        <h2 style="text-align: center;">
            <span style="font-family: 'times new roman';">Пример документа</span></h2></div>
    <div class="paragraph" id="eQFSL454" data-parentid="eYZSR214" level="2" data-id="e7084672A">
        <p style="TEXT-ALIGN: justify"></p>
        <div id="spreadsheetNonEditablePlace" contenteditable="false" onresizestart="stopResize()">
            <table ondragstart="event.returnValue = false;" id="ss78766D31" class="spreadsheet document-table" onselectstart="" contenteditable="false" style="TABLE-LAYOUT: fixed" cellspacing="0" cellpadding="0" version="4.2" onsenectstart="event.returnValue = false;" noresize="" align="justify" data-tablename="Место заключения" tabindex="1">
                <colgroup>
                    <col id="dd_col_HQEDKD6Z">
                    <col id="dd_col_273YFEBB">
                </colgroup>
                <thead><tr class="column-header-row" style="height: 0px">
                    <th id="dd_col_408A01A3" style="width:50%"></th>
                    <th id="dd_col_3E5B7099" style="width:50%"></th>
                </tr></thead>
                <tbody>
                <tr class="" style="HEIGHT: auto" l="1">
                    <td class="" style="VERTICAL-ALIGN: middle; TEXT-ALIGN: left" data-border-convert="true">
                        <p id="agency">
                            <strong>Орган - <span class="example_data"></span></strong><br>
                            <i id="comment1">Комментарий</i>
                        </p>
                    </td>
                    <td class="" style="VERTICAL-ALIGN: middle; TEXT-ALIGN: right" data-border-convert="true">
                        <p id="place">
                            <strong>Место - <span class="example_data"></span></strong><br>
                            <i id="comment2">Комментарий</i>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <p id="date_and_time" style="text-align: right">
                            <strong>Дата и время - <span class="example_data"></span></strong><br>
                            <i id="comment3">Комментарий</i>
                        </p>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <p style="TEXT-ALIGN: justify"></p>
    </div>
    <div class="paragraph" id="eILVN212-1" data-parentid="ePLDD785" level="2" data-id="eFB9422EC-1">
        <p id="target" ><strong>Цель - <span class="example_data"></span></strong>
        </p>
        <i id="comment4">Комментарий</i>
    <div class="paragraph" id="eMNKI055" data-parentid="eWXMI975" level="1" hasnumber="1" data-id="e11">
        <h3 style="text-align: center;"><span class="autonum" style="font-family: 'times new roman';"></span>
            <span style="font-family: 'times new roman';">Lorem ipsum dolor sit amet. </span></h3>
    </div>
    <div class="paragraph" id="eNKDH097-2" data-parentid="eQJBF122" level="2" hasnumber="1" data-id="e275-2">
        <p><span class="autonum" style="font-family: 'times new roman';">1.1.</span>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
    </div>
    <div class="paragraph" id="eAVGI294-0" linkid="link67B22FA7" storedid="e0-0" textblock="true" data-parentid="eSZDA811" level="2" hasnumber="1" data-id="e64048311-0">
        <p><span class="autonum" style="font-family: 'times new roman';">1.2.</span>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
    </div>
        <div class="paragraph" id="eMNKI055" data-parentid="eWXMI975" level="1" hasnumber="1" data-id="e11">

            <h3 style="text-align: center;"><span class="autonum" style="font-family: 'times new roman';"></span>
                <span style="font-family: 'times new roman';">Lorem ipsum dolor sit amet. </span></h3>
        </div>
        <div class="paragraph" id="eNKDH097-2" data-parentid="eQJBF122" level="2" hasnumber="1" data-id="e275-2">
            <p id="participant"><span class="autonum" style="font-family: 'times new roman';">2.1.</span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br>
                <strong>Количество участников - <span class="example_data"></span></strong><br>
                <i id="comment5">Комментарий</i>
            </p>
        </div>
        <div class="paragraph" id="eAVGI294-0" linkid="link67B22FA7" storedid="e0-0" textblock="true" data-parentid="eSZDA811" level="2" hasnumber="1" data-id="e64048311-0">
            <p><span class="autonum" style="font-family: 'times new roman';">2.2.</span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
        </div>
        <div class="paragraph" id="eMNKI055" data-parentid="eWXMI975" level="1" hasnumber="1" data-id="e11">

            <h3 style="text-align: center;"><span class="autonum" style="font-family: 'times new roman';"></span>
                <span style="font-family: 'times new roman';">Lorem ipsum dolor sit amet. </span></h3>
        </div>
        <div class="paragraph" id="eNKDH097-2" data-parentid="eQJBF122" level="2" hasnumber="1" data-id="e275-2">
            <p><span class="autonum" style="font-family: 'times new roman';">3.1.</span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
            <p id="yes_or_no">
                <strong>Планируется ли банкет? - <span class="example_data"></span></strong>
                <i id="comment6">Комментарий</i>
            </p>
        </div>
        <div class="paragraph" id="eAVGI294-0" linkid="link67B22FA7" storedid="e0-0" textblock="true" data-parentid="eSZDA811" level="2" hasnumber="1" data-id="e64048311-0">
            <p><span class="autonum" style="font-family: 'times new roman';">3.2.</span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
        </div>

    <p id="fio" style="text-align: right">
        <strong><span class="example_data">ФИО</span></strong><br>
        <i id="comment7">Комментарий</i>
    </p>
    <p id="date" style="text-align: right">
        <strong><span class="example_data">Дата</span></strong><br>
        <i id="comment8">Комментарий</i>
    </p>
   </div>