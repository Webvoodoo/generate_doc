/*
Scripts for user part
*/
//use notation jquery noConflict
jQuery(document).ready(function($) {
    $('input').on('change', function () {
        var ids = $(this).attr('id'),
            vals = $(this).val();
        $("#contents").find('p#' + ids).find('span.example_data').html(vals);
    });
    $('textarea').on('change', function () {
        $(this).each(function(){
            var ids = $(this).attr('id'),
                vals = $(this).val();
            $("#contents").find('i#' + ids).html(vals);
        });
    });
});