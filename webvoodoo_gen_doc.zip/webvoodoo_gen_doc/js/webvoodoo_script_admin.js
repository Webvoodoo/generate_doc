/*
Scripts for admin part
*/
//use notation jquery noConflict
jQuery(document).ready(function($) {
    $("#save_webvoodoo_name_page").click(function(e) {
        e.preventDefault();
        var page = $("#webvoodoo_page_setting").val(),
            action = $(this).data("action");
        //console.log(page);
        if(page === "") {
            alert("Укажите название страницы");
            return false;
        } else {
            if(action === "change") {
                if(!confirm("Подтвердите изменение")) return false;
                else {
                    $.ajax({
                        type: "POST",
                        url: ajaxurl,
                        data: {
                            action: 'webvoodoo_set_page_name', // part of name function which add post to DB
                            security: webvoodooDoc.nonce,
                            pageName: page,
                            dataAction: action
                        },
                        beforeSend: function () {
                            //loader
                        },
                        success: function (result) {
                            if(!result) alert("Такой страницы не существует");
                            else {
                                $("#web_page_name span").html(result);
                                $("#webvoodoo_page_setting").val("");
                            }
                            console.log(result);
                        },
                        error: function () {
                            console.log("Ошибка запроса!");
                        }
                    });
                }
            } else {
                $.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: {
                        action: 'webvoodoo_set_page_name', // part of name function which add post to DB
                        security: webvoodooDoc.nonce,
                        pageName: page,
                        dataAction: action
                    },
                    beforeSend: function () {
                        //loader
                    },
                    success: function (result) {
                        if(!result) alert("Такой страницы не существует");
                        else {
                            $("#web_page_name span").html(result);
                            $(this).css('display', 'none');
                            $("#webvoodoo_page_setting").val("");
                        }
                        console.log(result);
                    },
                    error: function () {
                        console.log("Ошибка запроса!");
                    }
                });
            }
        }

    });

    $("#webvoodoo_widget_del_docs").click(function (e) {
        alert(1);
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                action: 'webvoodoo_del_docs', // part of name function which add post to DB
            },
            success: function (result) {
                $("#webvoodoo_count").html('0');
                console.log(result);
            },
            error: function () {
                console.log("Ошибка запроса!");
            }
        });
    });
});